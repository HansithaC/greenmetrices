import math
while True:
    math.factorial(100000)
